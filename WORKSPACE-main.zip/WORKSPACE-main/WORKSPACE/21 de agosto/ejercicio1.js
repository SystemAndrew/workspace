function llamar () {
    const texto=document.getElementById("texto")
    alert(texto.value); 
}
