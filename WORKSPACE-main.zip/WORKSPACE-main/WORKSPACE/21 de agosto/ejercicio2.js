function llamar () {
    const texto=document.getElementById("texto")
    console.log(texto.value); 
}
