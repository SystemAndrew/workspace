const titleElement = document.querySelector (".title");
titleElement.innerHTML = "Este si es el titulo";
