const listElement = document.querySelector (".contraseña");
listElement.innerHTML = "***";