const sectionb = document.querySelector (".sectionb");
sectionb.classList.add ("hidden");